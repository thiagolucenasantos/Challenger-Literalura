package br.com.thiago.literalura.catalogo_de_livros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatalogoDeLivrosApplicationTests {

	@Test
	void contextLoads() {
	}

}
